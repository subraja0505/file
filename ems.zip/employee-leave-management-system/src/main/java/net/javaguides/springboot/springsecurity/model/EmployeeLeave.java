package net.javaguides.springboot.springsecurity.model;



import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class EmployeeLeave {
	private Long leaveid;
	private String startdate;
	private String enddate;
	private String reason;
	public String status;
	@OneToMany(targetEntity=User.class)
	private Long id;
	
	public EmployeeLeave() {
	}

	protected EmployeeLeave(Long leaveid,String startdate,String enddate, String reason, String status,Long id) {
		super();
		this.leaveid = leaveid;
		this.startdate = startdate;
		this.enddate = enddate;
		this.reason = reason;
		this.status = status;
		
		this.id=id;
	}
	
	    
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Long getLeaveid() {
		return leaveid;
	}

	public void setLeaveId(Long leaveid) {
		this.id = leaveid;
	}

	public String getStartdate() {
		return startdate;
	}

	public void setStartdate(String startdate) {
		this.startdate = startdate;
	}

	public String getEnddate() {
		return enddate;
	}

	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
	public void setLeaveid(Long leaveid) {
		this.leaveid = leaveid;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

}