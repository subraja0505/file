package net.javaguides.springboot.springsecurity.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import net.javaguides.springboot.springsecurity.model.EmployeeLeave;
import net.javaguides.springboot.springsecurity.service.EmployeeLeaveService;

@Controller
public class EmployeeLeaveController {
	@Autowired
	EmployeeLeaveService service;

	@RequestMapping("/adminhome")
	public String viewHomePage(Model model) {
		List<EmployeeLeave> listProducts = service.listAll();
		model.addAttribute("listProducts", listProducts);
		return "adminhome";
	}

	@RequestMapping("/apply")
	public String showNewProductPage(Model model) {
		EmployeeLeave product = new EmployeeLeave();
		model.addAttribute("product", product);
		return "employee_leave";
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveProduct(@ModelAttribute("product") EmployeeLeave product) {
		service.save(product);
		return "redirect:/";
	}

	@RequestMapping("/showall")
	public String viewLeavePage(Model model) {
		List<EmployeeLeave> listProducts = service.listAll();
		model.addAttribute("listProducts", listProducts);
		return "showall";
	}

	
}
    
